package com.example.gogreenlah;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {

    private Context context;
    private List<ImageUpload> uploads;

    public ImageAdapter(Context context, List<ImageUpload> uploads) {
        this.context = context;
        this.uploads = uploads;
    }

    @Override
    public ImageViewHolder onCreateViewHolder( ViewGroup parent, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.upload_image_item,parent, false);
        return new ImageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ImageViewHolder imageViewHolder, int i) {
        ImageUpload uploadCurrent = uploads.get(i);
        imageViewHolder.textViewName.setText(uploadCurrent.getImageName());
        Picasso.get().load(uploadCurrent.getImageUrl())
               // .fit()
               // .centerCrop()
                .into(imageViewHolder.imageView);
    }

    @Override
    public int getItemCount() {
        return uploads.size();
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewName;
        public ImageView imageView;


        public ImageViewHolder(View itemView) {
            super(itemView);

            textViewName = itemView.findViewById(R.id.textViewName);
            imageView = itemView.findViewById(R.id.imageViewUpload);
        }
    }
}
